insert into Noticia (titulo,autor,fecha) values ('java 9 ha salido','cecilio','2018-01-01');
insert into Comentario (texto,autor,noticia_titulo) values ('bien!!!','pedro','java 9 ha salido');